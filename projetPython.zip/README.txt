### Le readme sera complété lors de la phase 2 ###

contrôle:
> ou d: déplace Rockford à Droite
< ou q: déplace Rockford à Gauche
^ ou z: déplace Rockford en Haut
v ou s: déplace Rockford en bas
r     : reset
d     : debug mode (recliqué pour sortir du debug mode)


l'ajout des images se fera dans la phase 2
